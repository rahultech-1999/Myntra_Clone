const mongoose = require('mongoose')

const connectdatabse = ()=>{
    mongoose.connect("mongodb+srv://rahul20587:95TjDukFgoIem29e@cluster0.sg4cmw3.mongodb.net/?retryWrites=true&w=majority", {useNewUrlParser: true,
         useUnifiedTopology:true,
        }).then((data)=>{
        console.log(`Database connected ${data.connection.host}`)
    })

}

module.exports = connectdatabse